;; Define the classic bird combinators

;; B combinator (Bluebird) - function composition
(define B
  (lambda (f)
    (lambda (g)
      (lambda (x)
        (f (g x))))))

;; C combinator (Cardinal) - flips the order of arguments
(define C
  (lambda (f)
    (lambda (x)
      (lambda (y)
        (f y x)))))

;; T combinator (Thrush) - applies function to an argument
(define T
  (lambda (x)
    (lambda (f)
      (f x))))

;; K combinator (Kestrel) - returns the first argument
(define K
  (lambda (x)
    (lambda (y)
      x)))

;; I combinator (Identity) - returns the argument
(define I
  (lambda (x) x))

;; S combinator (Starling) - applies the function f to both arguments and then applies g
(define S
  (lambda (f)
    (lambda (g)
      (lambda (x)
        ((f x) (g x))))))

;; W combinator (Warbler) - duplicates the argument for the function
(define W
  (lambda (f)
    (lambda (x)
      (f x x))))

;; Y combinator (Sagebird) - enables recursion
(define Y
  (lambda (f)
    ((lambda (x) (f (lambda (y) ((x x) y))))
     (lambda (x) (f (lambda (y) ((x x) y)))))))

;; Define Church numerals

;; Church numeral 0
(define zero
  (lambda (f) (lambda (x) x)))

;; Church numeral 1
(define one
  (lambda (f) (lambda (x) (f x))))

;; Church numeral 2
(define two
  (lambda (f) (lambda (x) (f (f x)))))

;; Church numeral 3
(define three
  (lambda (f) (lambda (x) (f (f (f x))))))

;; Successor function for Church numerals
(define succ
  (lambda (n)
    (lambda (f) 
      (lambda (x)
        (f ((n f) x))))))

;; Addition for Church numerals
(define add
  (lambda (n m)
    (lambda (f) 
      (lambda (x)
        ((n f) ((m f) x))))))

;; Multiplication for Church numerals
(define mult
  (lambda (n m)
    (lambda (f) 
      (lambda (x)
        ((n (m f)) x)))))

;; Exponentiation for Church numerals
(define exp
  (lambda (n m)
    (lambda (f)
      (m n f))))

;; Convert Church numeral to a regular number (for display purposes)
(define to-int
  (lambda (n)
    ((n (lambda (x) (+ x 1))) 0)))  

;; Convert a regular number to a Church numeral
(define to-church
  (lambda (n)
    (if (= n 0)
        zero
        (succ (to-church (- n 1))))))

;; Example Usage: Rewriting the expression (B (lambda (x) (* x 2)) (lambda (x) (+ x 3)) 5)
;; using Church numerals.

;; Define Church numeral functions for doubling and adding 3
(define double
  (lambda (n)
    (mult two n)))

(define add3
  (lambda (n)
    (add n (to-church 3))))

;; Compose the two operations using the B combinator
(define composed-func
  ((B double) add3))

;; Example: Apply the composed function to the Church numeral for 5
(define result-church
(composed-func (to-church 5)))  

;; Convert the result back to an integer to view it
(to-int result-church)  ;; This will output 16, as expected
