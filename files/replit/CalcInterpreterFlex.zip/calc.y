%{

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int yylex();
extern int yyparse();
extern FILE* yyin;

void yyerror(const char* s);

%}

%union {
    int ival;
}

%token<ival> T_INT
%token T_PLUS T_MINUS T_MULTIPLY T_DIVIDE T_LEFT T_RIGHT T_NEWLINE

%type<ival> expr term factor addsub
%start calc

%%

calc:                               
    | calc line                     

line: T_NEWLINE  
    | expr T_NEWLINE                { printf("%d\n", $1); } 

expr: term addsub                   { $$ = $1 + $2; }

addsub:
	                                    { $$ = 0; } // the NULL case
	    | T_PLUS term addsub            { $$ = $2 + $3; }
	    | T_MINUS term addsub           { $$ = -$2 + $3; }

term: factor T_MULTIPLY term        { $$ = $1 * $3; }
    | factor T_DIVIDE term          { $$ = $1 / $3; }
    | factor                        { $$ = $1; }
    
factor: T_INT                       { $$ = $1; }
      | T_LEFT expr T_RIGHT         { $$ = $2; }
      
%%

int main() {
    yyin = stdin;
    
    do {
        yyparse();
    } while(!feof(yyin));
}

void yyerror(const char* s) {
    fprintf(stderr, "Parse error: %s\n", s);
    exit(1);
}