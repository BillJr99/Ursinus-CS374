{ pkgs }: {
	deps = [
		pkgs.flex_2_5_35
  pkgs.bison_3_5
  pkgs.clang_12
		pkgs.ccls
		pkgs.gdb
		pkgs.gnumake
	];
}