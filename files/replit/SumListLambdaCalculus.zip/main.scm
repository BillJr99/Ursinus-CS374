(define Y
  (lambda (f)
    ((lambda (x) (f (lambda (y) ((x x) y))))
     (lambda (x) (f (lambda (y) ((x x) y))))))
)

(define sumlist
  (Y (lambda (f)
       (lambda (L)
         (if (null? (cdr L))
             (car L)
             (+ (car L) (f (cdr L))))))))

(sumlist (list 1 2 3))
